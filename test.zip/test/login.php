<?php
session_start();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <center>
        <h1>Login</h1>
        <form action="" method="post">
            <table>
                <tr>
                    <td>KTU-ID</td>
                    <td><input type="text" name="ktuid" id=""></td>
                </tr>
                <tr>
                    <td>Password : </td>
                    <td><input type="password" name="password" id=""></td>
                </tr>
                <tr>
                    <td colspan="2" align="center"><input type="submit" value="Login"></td>
                </tr>
                <tr>
                    <td colspan="2" align="center">Dont have an account?<a href="signup.php">Signup</a></td>
                </tr>
            </table>
        </form>
    </center>
</body>

</html>

<?php  
include "connection.php";

if($_POST){
    $ktuid = $_POST['ktuid'];
    $password = $_POST['password'];

    $sql = "Select ktuid,password from signup where ktuid='$ktuid' and password='$password'";
    $result = mysqli_query($connect, $sql);
    if(mysqli_num_rows($result)>0){
        $_SESSION['user'] = $ktuid;
        header('location:dataregister.php');
    }else{
        echo "<script>
            alert('Login Failed! Enter valid ID and Password')
        </script>";
    }
}
?>