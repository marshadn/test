<?php
include "session_check.php";
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <center>
        <form action="" method="post">
            <h3>Book Search</h3>
            <table>
                <tr>
                    <td>Book Name : </td>
                    <td><input type="text" name="bookname" id=""></td>
                </tr>
                <tr>
                    <td colspan="2" align="center"><input type="submit" value="search"></td>
                </tr>
            </table>
        </form>
    </center>
</body>

</html>


<?php
include "connection.php";

if($_POST){
    $bookname = $_POST['bookname'];

    $sql = "Select * from book where bookname='$bookname'";
    $result = mysqli_query($connect, $sql);
    if(mysqli_num_rows($result)>0){

        echo "<center><h1>Book Details</h1><br><table border='2' solid>
        <tr>
        <th>Book Id</th>
        <th>Book Name</th>
        <th>Book author</th>
        <th>No of Copies</th>
        </tr>";
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr><td>" . $row['bookid'] . "</td>
        <td>" . $row['bookname'] . "</td>
        <td>" . $row['author'] . "</td>
        <td>" . $row['copies'] . "</td></tr>";
        }

        echo "
    </table><center>";
        }else{
        echo "<script>alert('Book not Found!!')</script>";
        }
    }
?>