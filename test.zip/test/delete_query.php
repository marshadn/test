<?php
include 'session_check.php';

include 'connection.php';

if ($_POST) {
    $bookid = $_POST['bookid'];
    $sql = "delete from book where bookid='$bookid'";
    $result = mysqli_query($connect, $sql);
    if ($result) {
        echo "<script>
            alert('Book Deleted successfully')    
        </script>";
        echo "<script>location.href='http://localhost/test/book_details.php'</script>";
    }
}
