<?php
include "session_check.php";
include "connection.php";



$sql = "select * from book";
$result = mysqli_query($connect, $sql);
if(mysqli_num_rows($result)>0){
    echo "<center>
    <form method='post' action='bookpricequery.php'>
    <table>
    <tr>
    <td>Bookid : </td>
    <td><select style='width:180px' name='bookid'>";
    while($row=mysqli_fetch_assoc($result)){
        echo "<option value='{$row['bookid']}'>{$row['bookid']}</option>";
    }
    echo "</select></td>
    
    </tr><tr>
    <td>Book Price :</td>
    <td><input type='tel' name='bookprice'></td>
    </tr>
    <tr>
    <td colspan='2' align='center'><input type='submit'></td></tr></table>
    </form></center>";
}

$sql = "select * from bookdetails";
$result = mysqli_query($connect, $sql);
if (mysqli_num_rows($result) > 0) {
    echo "<center><table border='2' solid><tr>
    <th>Book Id</th>
    <th>Book Price</th></tr>
    ";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr></tr><td>{$row['bookid']}</td>
                <td>{$row['bookprice']}</td></tr>";
    }

    echo "

    </table></center>";
}

?>





