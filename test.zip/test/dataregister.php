<?php
include "session_check.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action='logout.php'>
        <input type='submit' value='Logout'>
    </form>
    <center>
        <h1>Book registration</h1>
        <form action="" method="post">
            <table>
                <tr>
                    <td>Book_Id :</td>
                    <td><input type="tel" name="bookid" id=""></td>
                </tr>
                <tr>
                    <td>Book Name :</td>
                    <td><input type="text" name="bookname" id=""></td>
                </tr>
                <tr>
                    <td>Author :</td>
                    <td><input type="text" name="author" id=""></td>
                </tr>
                <tr>
                    <td>No Of Copies :</td>
                    <td><select name="copies" id="" style="width:180px">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select></td>
                </tr>
                <tr>
                    <td colspan="2" align="center"><input type="submit" value="Register Book"></td>
                </tr>
            </table>
        </form>
        <a href="book_details.php"><button>Book Details</button></a>
    </center>
</body>

</html>


<?php
include "connection.php";


if ($_POST) {
    $bookid = $_POST['bookid'];
    $bookname = $_POST['bookname'];
    $author = $_POST['author'];
    $copies = $_POST['copies'];


    $sql = "INSERT into Book values('$bookid','$bookname','$author','$copies')";
    $result = mysqli_query($connect, $sql);
    if ($result) {
        echo "<script>alert('Book registerd sucessfully')</script>";
        echo "<script>location.href='http://localhost/test/search.php'</script>";
    } else {
        echo "<script>alert('Book registerd failed')</script>";
    }
}
?>