<?php

session_start();
if(!isset($_SESSION['user'])){
    echo "<script>alert('Login to continue')</script>";
    header('location:login.php');
}

?>