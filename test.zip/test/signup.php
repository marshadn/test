<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <center>
        <h1>Signup</h1>
        <form action="" name="form" method="post" onsubmit="return validateform()">
            <table>
                <tr>
                    <td>KTU-ID : </td>
                    <td><input type="text" name="ktuid" required></td>
                </tr>
                <tr>
                    <td>Username : </td>
                    <td><input type="text" name="username" required></td>
                </tr>
                <tr>
                    <td>Password : </td>
                    <td><input type="password" name="password" required></td>
                </tr>
                <tr>
                    <td colspan="2" align="center"><input type="submit" value="Signup"></td>
                </tr>
                <tr>
                    <td colspan="2" align="center">Already have an account?<a href="login.php">Login</a></td>
                </tr>
            </table>
        </form>
    </center>
    <script>
        function validateform() {

            var ktuid = document.form.ktuid.value;
            var username = document.form.username.value;
            var password = document.form.password.value;

            var ktuidregex = /^TVE23MCA-20.{2}$/;
            var passwordregex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d).{8,15}$/;

            if (ktuidregex.test(ktuid)) {

                document.form.ktuid.focus();
                return true;
            } else {
                alert("Enter valid KTU ID");
                return false;
            }

            if (passwordregex.test(password)) {
                document.form.password.focus();
            } else {
                alert("Password must contain atleast One capital letter and one number");
                return false;
            }
            return true;
        }

    </script>
</body>

</html>



<?php
include "connection.php";


if ($_POST) {
    $ktuid = $_POST['ktuid'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "INSERT into Signup values ('$ktuid','$username','$password')";
    $result = mysqli_query($connect, $sql);
    if ($result) {
        echo "<script>location.href='http://localhost/test/login.php'</script>";
        echo "<script>alert('Login to continue')</script>";
    }else{
        echo "<script>
            alert('Signup failed')
        </script>";
    }
}

?>