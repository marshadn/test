<?php
include "session_check.php";
include "connection.php";


if($_POST){
    $bookid = $_POST['bookid'];
    $bookprice = $_POST['bookprice'];


    $sql = "Insert into bookdetails values('$bookid','$bookprice')";
    $result = mysqli_query($connect, $sql);
    if($result){
        echo "<script>alert ('Price added')</script>";
        echo "<script>location.href='http://localhost/test/bookprice.php'</script>";
    }else{
        echo "<script>alert ('Failed')</script>";
    }
}


?>

