<?php

include "session_check.php";
include "connection.php";

$sql = "select * from book";
$result = mysqli_query($connect, $sql);
if (mysqli_num_rows($result) > 0) {
    echo "<form action='logout.php'>
            <input type='submit' value='Logout'>
        </form><br><center><h1>Book Details</h1><br><table border='2' solid>
        <tr>
        <th>Book Id</th>
        <th>Book Name</th>
        <th>Book author</th>
        <th>No of Copies</th>
        </tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr><td>" . $row['bookid'] . "</td>
        <td>" . $row['bookname'] . "</td>
        <td>" . $row['author'] . "</td>
        <td>" . $row['copies'] . "</td></tr>";
    }

    echo "
    </table><br><a href='search.php'><button>Search</button></a><br><br><a href='bookprice.php'><button>Price Add</button></a><br><br><a href='bookupdate.php'><button>Update Book</button></a><br><br><a href='delete.php'><button>Delete Book</button></a></center>";
}

?>


