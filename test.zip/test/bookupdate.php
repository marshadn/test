<?php
include 'session_check.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <center>
        <h1>Update Book</h1><br>
        <form action="" method="post">
            Book Id : <input type="text" name="bookid" id="">
            <input type="submit" value="Submit">
        </form>
    </center>
</body>

</html>
<?php
include "connection.php";

if ($_POST) {
    $bookid = $_POST['bookid'];

    $sql = "select * from book where bookid='$bookid'";
    $result = mysqli_query($connect, $sql);
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        echo "<br><br><center><form method='post' action='update_query.php'>
    <table>
                <tr>
                    <td>Book_Id :</td>
                    <td><input type='tel' name='bookid' value='{$row['bookid']}' readonly></td>
                </tr>
                <tr>
                    <td>Book Name :</td>
                    <td><input type='text' name='bookname' value='{$row['bookname']}'></td>
                </tr>
                <tr>
                    <td>Author :</td>
                    <td><input type='text' name='author' value='{$row['author']}'></td>
                </tr>
                <tr>
                    <td>No Of Copies :</td>
                    <td><select name='copies'style='width:180px' value='{$row['copies']}'>
                            <option value='1'>1</option>
                            <option value='2'>2</option>
                            <option value='3'>3</option>
                            <option value='4'>4</option>
                            <option value='5'>5</option>
                        </select></td>
                </tr>
                <tr>
                    <td colspan='2' align='center'><input type='submit' value='Update Book'></td>
                </tr>
            </table></center>";
    }
}

?>