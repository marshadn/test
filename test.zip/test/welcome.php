<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <center>
        <h1>Welcome to my page </h1><br>
        <a href="login.php"><button>Login Page</button></a>
    </center>
</body>
</html>